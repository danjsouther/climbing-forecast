const aws = require('aws-sdk');
const request = require('request');

aws.config.update({region: 'us-east-2'});
aws.config.apiVersions = {
  dynamodb: '2012-08-10'
};

const docClient = new aws.DynamoDB.DocumentClient();

module.handler = function(event, contect, callback){

  // Get climbing list of climbing locations
  getLocations().then(function(locations){
    return Promise.all( locations.map(getForecast) );

  }).then(function(forecasts){
    return Promise.all( forecasts.map(saveForecast) );

  }).then(() => callback(null, "success"))
  .catch(callback);
}

function getLocations(){
  return new Promise(function(resolve, reject){
    const params = { TableName: 'ClimbingLocations' }
    docClient.scan(params, function(error, results){
      if (error) {
        reject(error);
      } else {
        resolve(results.Items)
      }
    })
  })
};

function getForecast(location){
  return new Promise(function(resolve,reject){
    const exclude = ['currently','minutely','alerts','flags','hourly']
    const url = `https://api.darksky.net/forecast/${darkSkySecret}/${location.latitude},${location.longitude}?exclude=${exclude.join(',')}`
    request.get(url, function(error, results){
      if (error) {
        reject(error);
      } else {
        results.locationName = location.name
        resolve(results);
      }
    });
    
  });
};

function saveForecast(forecast){
  new Promise(function(resolve, reject){
    const puts = forecast.map(setupRequest).reduce(function(a,b){return a.concat(b)},[])
    const params = {
      RequestItems: {
        'DarkSkyForecasts': puts
      }
    }
  });
};

function setupRequest(forecast){
  return forecast.daily.map(function(dayForecast){
    return PutRequests: {
        Item: {
          "location": { S: forecast.locationName },
          "time": { N: dayForecast.time },
          "latitude": { N: forecast.latitude },
          "longitude": { N: forecast.longitude },
          "icon": { N: dayForecast.icon },
          "sunriseTime": { N: dayForecast.sunriseTime },
          "sunsetTime": { N: dayForecast.sunsetTime },
          "moonPhase": { N: dayForecast.moonPhase },
          "precipIntensity": { N: dayForecast.precipIntensity },
          "precipIntensityMax": { N: dayForecast.precipIntensityMax },
          "precipIntensityMaxTime": { N: dayForecast.precipIntensityMaxTime },
          "precipProbability": { N: dayForecast.precipProbability },
          "precipAccumulation": { N: dayForecast.precipAccumulation },
          "precipType": { N: dayForecast.precipType },
          "temperatureHigh": { N: dayForecast.temperatureHigh },
          "temperatureHighTime": { N: dayForecast.temperatureHighTime },
          "temperatureLow": { N: dayForecast.temperatureLow },
          "temperatureLowTime": { N: dayForecast.temperatureLowTime },
          "apparentTemperatureHigh": { N: dayForecast.apparentTemperatureHigh },
          "apparentTemperatureHighTime": { N: dayForecast.apparentTemperatureHighTime },
          "apparentTemperatureLow": { N: dayForecast.apparentTemperatureLow },
          "apparentTemperatureLowTime": { N: dayForecast.apparentTemperatureLowTime },
          "dewPoint": { N: dayForecast.dewPoint },
          "humidity": { N: dayForecast.humidity },
          "pressure": { N: dayForecast.pressure },
          "windSpeed": { N: dayForecast.windSpeed },
          "windBearing": { N: dayForecast.windBearing },
          "cloudCover": { N: dayForecast.cloudCover },
          "uvIndex": { N: dayForecast.uvIndex },
          "uvIndexTime": { N: dayForecast.uvIndexTime },
          "visibility": { N: dayForecast.visibility}
        }
      }
  });
    
};
